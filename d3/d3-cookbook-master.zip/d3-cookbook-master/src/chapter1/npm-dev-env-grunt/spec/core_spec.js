describe('core', function () {
    it('has version', function () {
        expect(project.version).not.toBe(null);
    });
});