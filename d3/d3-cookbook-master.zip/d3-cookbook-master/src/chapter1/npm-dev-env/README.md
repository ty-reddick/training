* Apache Ant based project template - npm-dev-env-ant
* Grunt.js based project template - npm-dev-env-grunt